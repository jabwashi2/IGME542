I chose to add a specular map to the project! I believe I used the right png for the specular, though if something seems of please let me know :)

I loaded in the file like any other texture and multiplied it's r channel by the specularity inside of the light calculation functions.