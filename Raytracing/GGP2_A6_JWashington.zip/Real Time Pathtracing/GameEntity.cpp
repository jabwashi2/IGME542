#include "GameEntity.h"

GameEntity::GameEntity(std::string _name, std::shared_ptr<Mesh> mesh_ptr, std::shared_ptr<Material> mtrl_ptr)
{
    this->name = _name;

    myMesh = mesh_ptr;
    myTransform = std::make_shared<Transform>();
    myMaterial = mtrl_ptr;
}

std::shared_ptr<Mesh> GameEntity::GetMesh()
{
    return myMesh;
}

std::shared_ptr<Material> GameEntity::GetMaterial() {
    return myMaterial;
}

// set up if needed
void GameEntity::SetMesh()
{

}

void GameEntity::SetMaterial(std::shared_ptr<Material> mtrl_ptr)
{
    this->myMaterial = mtrl_ptr;
}

std::shared_ptr<Transform> GameEntity::GetTransform()
{
    return myTransform;
}
